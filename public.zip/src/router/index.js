import Vue from 'vue'
import Router from 'vue-router'
import FeedbackForm from '@/components/FeedbackForm'
import Suggestion from '@/components/Suggestion'
import Home from "@/components/Home"

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/feedback',
      name: 'feedback',
      component: FeedbackForm
    },
    {
      path: '/suggest',
      name: 'Suggestion',
      component: Suggestion
    }
  ]
})

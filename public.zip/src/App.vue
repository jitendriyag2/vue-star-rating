<template>
  <div id="app">
    <v-layout>
        <section>
            <v-container grid-list-xl>
              <v-layout row wrap justify-space-between>
                <div xs6>
                  <v-card class="elevation-400">
                    <v-card-title primary-title class="layout justify-center">
                      <div class="headline">Company info</div>
                    </v-card-title>
                    <v-card-text>
                      Cras facilisis mi vitae nunc lobortis pharetra. Nulla volutpat tincidunt ornare. 
                      Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. 
                      Nullam in aliquet odio. Aliquam eu est vitae tellus bibendum tincidunt. Suspendisse potenti. 
                    </v-card-text>
                  </v-card>
                </div>
                <div xs6 offset-sm1>
                  <v-card class="elevation-400">
                    <v-card-title primary-title class="layout justify-center">
                      <div class="headline">Contact us</div>
                    </v-card-title>
                    <v-card-text>
                      Cras facilisis mi vitae nunc lobortis pharetra. Nulla volutpat tincidunt ornare.
                    </v-card-text>
                    <v-list class="transparent">
                      <v-list-tile>
                        <v-list-tile-action>
                          <v-icon class="blue--text text--lighten-2">phone</v-icon>
                        </v-list-tile-action>
                        <v-list-tile-content>
                          <v-list-tile-title>777-867-5309</v-list-tile-title>
                        </v-list-tile-content>
                      </v-list-tile>
                      <v-list-tile>
                        <v-list-tile-action>
                          <v-icon class="blue--text text--lighten-2">place</v-icon>
                        </v-list-tile-action>
                        <v-list-tile-content>
                          <v-list-tile-title>Chicago, US</v-list-tile-title>
                        </v-list-tile-content>
                      </v-list-tile>
                      <v-list-tile>
                        <v-list-tile-action>
                          <v-icon class="blue--text text--lighten-2">email</v-icon>
                        </v-list-tile-action>
                        <v-list-tile-content>
                          <v-list-tile-content>
                            <star-rating></star-rating>
                          </v-list-tile-content>
                        </v-list-tile-content>
                      </v-list-tile>
                    </v-list>
                  </v-card>
                </div>
              </v-layout>
            </v-container>
        </section>
    </v-layout>
   
    
  </div>
</template>

<script>
import StarRating from './components/StarRating.vue'
import 'vuetify/dist/vuetify.min.css'
export default {
    components: {
        StarRating
    },
    created:{

    },
    data() {
          return {
            support: 0,
            timely: 0
            }
    }
}

</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

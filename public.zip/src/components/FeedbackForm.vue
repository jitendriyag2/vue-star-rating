<template>
    <v-content>
        <div>
            <star-rating v-model="support"></star-rating>
        {{support}}
            </div>
            
        <div>
            <star-rating v-model="timely"></star-rating>
        {{timely}}
            </div>
    </v-content>
</template>

<script>
import StarRating from './StarRating.vue'

export default {
    components: {
        StarRating
    },
    created() {
       setTimeout(() => {
            this.rating = 3.5
        }, 1000)
    },
    data() {
        return {
            support: 0,
            timely : 0
        }
    }
}

</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

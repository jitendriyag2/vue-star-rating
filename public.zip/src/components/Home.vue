<template>
    <v-content>
        <v-layout row wrap>
            <v-flex>
                <h1>Home</h1>
                <span>
                    {{greeting}}
                </span>
            </v-flex>
        </v-layout>
    </v-content>
</template>

<script>
export default { greeting: null,
  data () { return { greeting: 'Hello Jitu' } }
}
</script>

<style>

</style>
